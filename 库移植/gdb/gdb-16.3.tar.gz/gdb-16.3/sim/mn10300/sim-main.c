/**
 * This isn't normally compiled, but is pulled in via sim-inline.c when the
 * SIM_MAIN_INLINE option is enabled by the user at compile time.
 */

#ifndef SIM_MAIN_C
#define SIM_MAIN_C
#include "op_utils.c"
#endif
